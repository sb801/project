<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Edge Home</title>
	<link rel="stylesheet" href="style.css">

	</head>
	<body>

		<div class="header">
		  <h1>EDGE: CSEBU Digital Skills Training Program</h1>
		</div>

		<div class="topnav">
		  <a href="index.php">Announcement</a>
		  <a href="courses.php">Offered Courses</a>
		  <a href="application.php">Apply Online</a>
		</div>
		
		
		
		